
def etl_test_func(event, context):
  print("LAMBDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
  print(event)
  print(context)